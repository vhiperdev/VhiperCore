/*
Navicat MySQL Data Transfer

Source Server         : LocalHost
Source Server Version : 50639
Source Host           : localhost:3306
Source Database       : vp_auth

Target Server Type    : MYSQL
Target Server Version : 50639
File Encoding         : 65001

Date: 2019-05-23 22:54:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `sha_pass_hash` varchar(40) NOT NULL DEFAULT '',
  `sessionkey` varchar(80) NOT NULL DEFAULT '',
  `v` varchar(64) NOT NULL DEFAULT '',
  `s` varchar(64) NOT NULL DEFAULT '',
  `token_key` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `reg_mail` varchar(255) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `last_attempt_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lock_country` varchar(2) NOT NULL DEFAULT '00',
  `last_login` timestamp NULL DEFAULT NULL,
  `online` int(10) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Account System';

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('0000000001', 'ADM', '07F489AB4F6186E763BF1812D993476EBDF62798', 'ABF70BE9B34317B5331C91FFADC5895E486CB88CF2FD8A4EE13EB8612E77C4A8BE5F38258EA8210F', '7952BAD6E05A1DA7F71004AD9D0DFABEA9894DA1795BCCCBAAECB00D81A19BDB', 'AD863ED60916200970ABA336BBB7CD19C6E0C2B78932B65FD6E19930B9BED0CF', '', '', '', '2019-05-20 21:38:34', '127.0.0.1', '127.0.0.1', '0', '0', '00', '2019-05-23 21:25:32', '1', '2', '0', '', '', '0', 'Win', '0', '6224');
INSERT INTO `account` VALUES ('0000000002', 'TEST', 'e4466edaae6186f5497c4e95732df9d81624b36a', '93F4B7068EC403F7A096D8B1CB93542212F7BB842912C87DDCED49BDFA3D95F57CA0D4B78F1D4E9E', '55516AADC03A6E0598F382A9A8B6C94A7510D6A52F326F42E8BBD7AE7DF09155', '90F2A887F4F69554E77B8CE01F8EB1EA96B2585BE4850A57F4D020CD97F53EC9', '', 'asdqwe@live.com', '', '2019-05-21 01:36:29', '127.0.0.1', '127.0.0.1', '0', '0', '00', '2019-05-22 00:58:32', '0', '2', '0', '', '', '0', 'Win', '0', '78');

-- ----------------------------
-- Table structure for account_access
-- ----------------------------
DROP TABLE IF EXISTS `account_access`;
CREATE TABLE `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_access
-- ----------------------------
INSERT INTO `account_access` VALUES ('1', '4', '1');
INSERT INTO `account_access` VALUES ('2', '4', '-1');

-- ----------------------------
-- Table structure for account_banned
-- ----------------------------
DROP TABLE IF EXISTS `account_banned`;
CREATE TABLE `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';

-- ----------------------------
-- Records of account_banned
-- ----------------------------

-- ----------------------------
-- Table structure for account_muted
-- ----------------------------
DROP TABLE IF EXISTS `account_muted`;
CREATE TABLE `account_muted` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mutedate` int(10) unsigned NOT NULL DEFAULT '0',
  `mutetime` int(10) unsigned NOT NULL DEFAULT '0',
  `mutedby` varchar(50) NOT NULL,
  `mutereason` varchar(255) NOT NULL,
  PRIMARY KEY (`guid`,`mutedate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='mute List';

-- ----------------------------
-- Records of account_muted
-- ----------------------------

-- ----------------------------
-- Table structure for autobroadcast
-- ----------------------------
DROP TABLE IF EXISTS `autobroadcast`;
CREATE TABLE `autobroadcast` (
  `realmid` int(11) NOT NULL DEFAULT '-1',
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `weight` tinyint(3) unsigned DEFAULT '1',
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`,`realmid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of autobroadcast
-- ----------------------------
INSERT INTO `autobroadcast` VALUES ('-1', '1', '1', 'Bem-Vindos ao repack do projeto VhiperCore');

-- ----------------------------
-- Table structure for ip2nation
-- ----------------------------
DROP TABLE IF EXISTS `ip2nation`;
CREATE TABLE `ip2nation` (
  `ip` int(11) unsigned NOT NULL DEFAULT '0',
  `country` char(2) NOT NULL DEFAULT '',
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ip2nation
-- ----------------------------

-- ----------------------------
-- Table structure for ip2nationcountries
-- ----------------------------
DROP TABLE IF EXISTS `ip2nationcountries`;
CREATE TABLE `ip2nationcountries` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `iso_code_2` varchar(2) NOT NULL DEFAULT '',
  `iso_code_3` varchar(3) DEFAULT '',
  `iso_country` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(255) NOT NULL DEFAULT '',
  `lat` float NOT NULL DEFAULT '0',
  `lon` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`code`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ip2nationcountries
-- ----------------------------

-- ----------------------------
-- Table structure for ip_banned
-- ----------------------------
DROP TABLE IF EXISTS `ip_banned`;
CREATE TABLE `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Banned IPs';

-- ----------------------------
-- Records of ip_banned
-- ----------------------------

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `time` int(10) unsigned NOT NULL,
  `realm` int(10) unsigned NOT NULL,
  `type` varchar(250) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `string` text CHARACTER SET latin1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of logs
-- ----------------------------

-- ----------------------------
-- Table structure for logs_ip_actions
-- ----------------------------
DROP TABLE IF EXISTS `logs_ip_actions`;
CREATE TABLE `logs_ip_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique Identifier',
  `account_id` int(10) unsigned NOT NULL COMMENT 'Account ID',
  `character_guid` int(10) unsigned NOT NULL COMMENT 'Character Guid',
  `type` tinyint(3) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `systemnote` text COMMENT 'Notes inserted by system',
  `unixtime` int(10) unsigned NOT NULL COMMENT 'Unixtime',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Timestamp',
  `comment` text COMMENT 'Allows users to add a comment',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Used to log ips of individual actions';

-- ----------------------------
-- Records of logs_ip_actions
-- ----------------------------

-- ----------------------------
-- Table structure for realmcharacters
-- ----------------------------
DROP TABLE IF EXISTS `realmcharacters`;
CREATE TABLE `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Realm Character Tracker';

-- ----------------------------
-- Records of realmcharacters
-- ----------------------------
INSERT INTO `realmcharacters` VALUES ('1', '1', '2');
INSERT INTO `realmcharacters` VALUES ('1', '2', '1');
INSERT INTO `realmcharacters` VALUES ('1', '12', '0');

-- ----------------------------
-- Table structure for realmlist
-- ----------------------------
DROP TABLE IF EXISTS `realmlist`;
CREATE TABLE `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '12340',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Realm System';

-- ----------------------------
-- Records of realmlist
-- ----------------------------
INSERT INTO `realmlist` VALUES ('1', 'VhiperCore', '127.0.0.1', '127.0.0.1', '255.255.255.0', '8085', '0', '0', '3', '0', '0', '12340');

-- ----------------------------
-- Table structure for uptime
-- ----------------------------
DROP TABLE IF EXISTS `uptime`;
CREATE TABLE `uptime` (
  `realmid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `uptime` int(10) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'AzerothCore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Uptime system';

-- ----------------------------
-- Records of uptime
-- ----------------------------
INSERT INTO `uptime` VALUES ('1', '1550400304', '121', '0', 'AzerothCore rev. 2bcedc2859e7 2019-02-17 10:04:09 +0100 (master branch) (Unix, Debug)');
INSERT INTO `uptime` VALUES ('1', '1550400454', '1440', '0', 'AzerothCore rev. 2bcedc2859e7 2019-02-17 10:04:09 +0100 (master branch) (Unix, Debug)');
INSERT INTO `uptime` VALUES ('1', '1558394981', '313', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558396193', '0', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558396591', '204', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558397525', '0', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558397863', '510', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558399019', '369', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558400853', '317', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558401253', '0', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558402140', '60', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558402337', '61', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558402942', '74', '0', 'VhiperCore rev. 23618dc38d6b+ 2019-05-20 18:42:46 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558405661', '580', '1', 'VhiperCore rev. dd4316fa28c5+ 2019-05-20 22:44:30 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558406324', '918', '1', 'VhiperCore rev. dd4316fa28c5+ 2019-05-20 22:44:30 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558411390', '160', '0', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558413323', '296', '2', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558468154', '988', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558470044', '3680', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558473888', '382', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558479867', '564', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558480747', '259', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558481408', '507', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558482180', '379', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558482774', '980', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558485267', '262', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558488869', '860', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558490104', '745', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558490997', '447', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558493911', '0', '0', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558494699', '1164', '1', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558497277', '377', '2', 'VhiperCore rev. 635da827113c+ 2019-05-21 00:12:22 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558552878', '917', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558555899', '767', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558556951', '1612', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558558768', '501', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558559606', '862', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558560820', '271', '1', 'VhiperCore rev. 652d990ed0df+ 2019-05-22 15:39:12 -0300 (master branch) (Win32, Release)');
INSERT INTO `uptime` VALUES ('1', '1558657281', '870', '1', 'VhiperCore rev. 844b29c263b5 2019-05-23 21:03:10 -0300 (master branch) (Win32, Release)');

-- ----------------------------
-- Table structure for version_db_auth
-- ----------------------------
DROP TABLE IF EXISTS `version_db_auth`;
CREATE TABLE `version_db_auth` (
  `sql_rev` varchar(100) NOT NULL,
  `required_rev` varchar(100) DEFAULT NULL,
  `2019_04_13_00` bit(1) DEFAULT NULL,
  PRIMARY KEY (`sql_rev`),
  KEY `required` (`required_rev`),
  CONSTRAINT `required` FOREIGN KEY (`required_rev`) REFERENCES `version_db_auth` (`sql_rev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of version_db_auth
-- ----------------------------
INSERT INTO `version_db_auth` VALUES ('1554142988374631100', null, null);
